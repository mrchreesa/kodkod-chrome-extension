import"./modulepreload-polyfill-B5Qt9EMX.js";const e=localStorage.getItem("kodkod_print_content"),n=localStorage.getItem("kodkod_print_title");if(e){let t=e;n&&(t=t.replace(/<title>[^<]*<\/title>/,`<title>${n}</title>`)),t=t.replace("</head>",`<style>
      @media print {
        body { padding: 0 !important; margin: 0 !important; }
        @page { margin: 0.5in; size: letter; }
      }
    </style>
    </head>`),document.open(),document.write(t),document.close(),setTimeout(()=>{window.print()},500)}else document.body.innerHTML='<div style="padding: 20px; font-family: sans-serif;">No content to print. Please try again.</div>';
