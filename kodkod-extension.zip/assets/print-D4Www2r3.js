import{R as a,j as r,a as i,r as d}from"./index-5hNFgDiF.js";const s=()=>{const t=i.useRef(!1);return d.useEffect(()=>{if(t.current)return;t.current=!0;const e=localStorage.getItem("kodkod_print_content"),n=localStorage.getItem("kodkod_print_title");if(e){n&&(document.title=n),document.body.innerHTML=e;const o=document.createElement("style");o.innerHTML=`
        @media print {
          body { padding: 0 !important; margin: 0 !important; }
          @page { margin: 0.5in; size: letter; }
        }
      `,document.head.appendChild(o),setTimeout(()=>{window.print()},500)}else document.body.innerHTML='<div style="padding: 20px; font-family: sans-serif;">No content to print. Please try again.</div>'},[]),null};a.createRoot(document.getElementById("root")).render(r.jsx(i.StrictMode,{children:r.jsx(s,{})}));
